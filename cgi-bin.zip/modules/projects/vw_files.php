<?php /* PROJECTS $Id: vw_files.php,v 1.8 2004/08/06 05:22:47 cyberhorse Exp $ */
GLOBAL $AppUI, $project_id, $deny, $canRead, $canEdit, $dPconfig;

$showProject = false;
require( "{$dPconfig['root_dir']}/modules/files/index_table.php" );
?>
