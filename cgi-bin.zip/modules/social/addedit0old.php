<?php
$social_id = intval( dPgetParam( $_GET, "social_id", 0 ) );
$client_id = intval (dPgetParam($_REQUEST, 'client_id', 0));
require_once ($AppUI->getModuleClass('clients'));
require_once ($AppUI->getModuleClass('admission'));

// check permissions for this company
$perms =& $AppUI->acl();
// If the company exists we need edit permission,
// If it is a new company we need add permission on the module.
if ($social_id)
  $canEdit = $perms->checkModuleItem($m, "edit", $social_id);
else
  $canEdit = $perms->checkModule($m, "add");

if (!$canEdit) {
	$AppUI->redirect( "m=public&a=access_denied" );
}

// load the company types
$types = dPgetSysVal( 'CompanyType' );

// load the record data
$q  = new DBQuery;
$q->addTable('social_visit');
$q->addQuery('social_visit.*');
$q->addWhere('social_visit.social_id = '.$social_id);
$sql = $q->prepare();
//var_dump($sql);
$q->clear();

$obj = new CSocialVisit();
if (!db_loadObject( $sql, $obj ) && $social_id > 0)
{
	// $AppUI->setMsg( '	$qid =& $q->exec(); Company' ); // What is this for?
	$AppUI->setMsg( "invalidID", UI_MSG_ERROR, true );
	$AppUI->redirect();
}

if ($social_id > 0)
{
	$entry_date = intval( $obj->social_entry_date ) ? new CDate( $obj->social_entry_date ) : null;
}
else
{
	$entry_date = new CDate( $date );
}
$death_date =  intval($obj->social_death_date) ? new CDate( $obj->social_death_date ) : null;;

// collect all the users for the staff list
$q  = new DBQuery;
$q->addTable('contacts','con');
$q->leftJoin('users','u', 'u.user_contact = con.contact_id');
$q->addQuery('contact_id');
$q->addQuery('CONCAT_WS(", ",contact_last_name,contact_first_name)');
$q->addOrder('contact_last_name');
$owners = $q->loadHashList();


//load clinics

$q->clear();
$q->addTable('clinics', 'c');
$q->addQuery('c.clinic_id, c.clinic_name');
$q->addOrder('c.clinic_name');

$clinics = arrayMerge(array(0=> '-Select Center -'),$q->loadHashList());

$statusTypes = dPgetSysVal('ClientStatus');
$boolTypes = dPgetSysVal('YesNo');
$boolTypesND = dPgetSysVal('YesNoND');
$riskLevels = dPgetSysVal('RiskLevel');
$riskLevels = arrayMerge(array(-1=>'-Select Risk Level-'),$riskLevels );
$visitTypes = dPgetSysVal('SocialVisitTypes');
$deathTypes = dPgetSysVal('DeathTypes');
$caregiverChangeTypes = dPgetSysVal('CaregiverChangeTypes');
$caregiverHealthStatus = dPgetSysVal('CaregiverHealthStatus');
$caregiverHealthChanges =  dPgetSysVal('CaregiverHealthChanges');
$educationLevels =  dPgetSysVal('EducationLevel');
$genderTypes = dPgetSysVal('GenderType');
$employmentTypes =  dPgetSysVal('EmploymentType');
$socialstatusTypes = arrayMerge(array(0=>'-Select Client Status-'),dPgetSysVal('SocialClientStatus'));
$serviceTypes = arrayMerge(array(0=>'-Select Service-'),dPgetSysVal('ServiceTypes'));

$incomeLevels =  dPgetSysVal('IncomeLevels');
$relocationTypes = dPgetSysVal('RelocationType');
$reasonsNotAttendingSchool = dPgetSysVal('ReasonsNotAttendingSchool');
$igaTypes = dPgetSysVal('IGAOptions');
$placementTypes = dPgetSysVal('PlacementType');
$successionPlanningTypes = dPgetSysVal('SuccessionPlanningTypes');
$legalIssues = dPgetSysVal('LegalIssues');
$nursingCareTypes = dPgetSysVal('NursingCareTypes');
$transportNeeds = dPgetSysVal('TransportNeeds');
$educationNeeds = dPgetSysVal('EducationNeeds');
$foodNeeds = dPgetSysVal('FoodNeeds');
$rentNeeds = dPgetSysVal('RentNeeds');
$solidarityNeeds = dPgetSysVal('SolidarityNeeds');
$directSupportNeeds = dPgetSysVal('DirectSupportNeeds');
$medicalSupportNeeds = dPgetSysVal('MedicalSupportNeeds');
$childSchoolLevels = dPgetSysVal('ChildSchoolLevels');
$childSchoolStatus = dPgetSysVal('ChildSchoolStatus');
$clientHealth = dPgetSysVal('ClientHealth');
$trainingSupport = dPgetSysVal('TrainingSupport');
$positionOptions = arrayMerge(array(0=>'--Select Position--'),  dPgetSysVal('PositionOptions'));

$medical_support_options = explode(",",$obj->social_medical_support);

$direct_support_options = explode(",", $obj->social_direct_support);

$solidarity_options = explode(",", $obj->social_solidarity);


$rent_options = explode(",", $obj->social_rent);

$food_options = explode(",", $obj->social_food);

$education_options = explode(",", $obj->social_education);

$transport_options = explode(",", $obj->social_transport);

$nursing_options = explode(",", $obj->social_nursing);

$legal_options = explode(",", $obj->social_legal);


$succession_planning_options = explode(",", $obj->social_succession_planning);

$placement_options = explode(",", $obj->social_placement);

$iga_options = explode(",", $obj->social_iga);

$relocation_options = explode(",", $obj->social_relocation);

// format dates
$df = $AppUI->getPref('SHDATEFORMAT');

// setup the title block

//load client

if (!empty($client_id))
{
   $clientObj = new CClient();

   if (!$clientObj->load($client_id))
   {
		$AppUI->setMsg('Client ID');
		$AppUI->setMsg("invalidID", UI_MSG_ERROR, true);
		$AppUI->redirect("?m=clients");
   }
   $client_name =  $clientObj->getFullName();
}

$client_id = $client_id ? $client_id : $obj->social_client_id;

$careInfo = array('primary'=>array(),'secondary'=>array());
$q = new DBQuery();
$q->addTable('admission_caregivers');
$q->addOrder('id desc');
$q->setLimit(1);
$q->addWhere('client_id='.$client_id);
$q->addWhere('datesoff is not null');
$q1 = clone $q;
$q->addWhere('role="pri"');
$careInfo['primary'] = $q->loadHashList();

$q1->addWhere('role="sec');
$careInfo['secondary'] = $q1->loadHashList();

$clientObj = new CClient();
if ($clientObj->load($client_id))
{
	$ttl = $social_id > 0 ? "Edit Social Visit : " . $clientObj->getFullName() : "New Social Visit: " . $clientObj->getFullName();

}
else
{
   $ttl = $social_id > 0 ? "Edit Social Visit " : "New Social Visit ";

}

//load family members
if ($client_id > 0)
{
	$q = new DBQuery();
	$q->addTable("household_info");
	$q->addQuery("household_info.*");
	$q->addWhere("household_info.household_social_id = " . $social_id);
	$rows = $q->loadList();
}
if ($social_id > 0)
{
	$q = new DBQuery();
	$q->addTable("social_services");
	$q->addQuery("social_services.*");
	$q->addWhere("social_services.social_services_social_id = " . $social_id);
	$servicerows = $q->loadList();
}

if (!empty($client_id))
{
	$q  = new DBQuery;
	$q->addTable('admission_info');
	$q->addQuery('admission_info.*');
	$q->addWhere('admission_info.admission_client_id = '.$client_id);
	$sql = $q->prepare();
	//var_dump($sql);
	$q->clear();
	$admissionObj = new CAdmissionRecord();
	db_loadObject( $sql, $admissionObj );
}

$titleBlock = new CTitleBlock( $ttl, '', $m, "$m.$a" );
$titleBlock->addCrumb( "?m=clients", "Clients" );
$titleBlock->addCrumbRight2( "javascript:clearSelection(document.forms['changeSocial'])", "Clear All Selections" );
if ($client_id != 0)
	$titleBlock->addCrumb( "?m=clients&a=view&client_id=$client_id", "view " .$clientObj->getFullName());
/*
if ($social_id != 0)
  $titleBlock->addCrumb( "?m=social&a=view&social_id=$social_id", "View" );*/

$titleBlock->show();
?>

<script language="javascript">
function submitIt() {
	var form = document.changeSocial ;
	var count = 0;
	form.household_num_rows.value = document.getElementById('family').rows.length;
	form.service_num_rows.value = document.getElementById('services').rows.length;
	if (form.social_death_date && form.social_death_date.value.length > 0)
	{
		errormsg = checkValidDate(form.social_death_date.value);

		if (errormsg.length > 1)
		{
			alert("Invalid date" );
			form.social_death_date.focus();
			exit;
		}
	}
	if (form.social_entry_date && form.social_entry_date.value.length > 0)
	{
		errormsg = checkValidDate(form.social_entry_date.value);

		if (errormsg.length > 1)
		{
			alert("Invalid Entry date" );
			form.social_entry_date.focus();
			exit;
		}
	}
	 if (form.social_caregiver_age && form.social_caregiver_age.value.length > 0)
	{
		if (isNaN(parseInt(form.social_caregiver_age.value,10)) )
		{
			alert(" Invalid Age");
			form.social_caregiver_age.focus();
			exit;

		}
	}
	//validate yobs
	for (count = 1; count < document.getElementById('family').rows.length; count++)
	{
		var elementtocheck = document.getElementById('yob_'+ count)
		if (elementtocheck && elementtocheck.value.length > 0)
		{
			var lval=elementtocheck.value;
			if(checkValidDate(lval) == 0){
				var tyr=lval.split("/");
				lval=tyr[2];
				elementtocheck.value=lval;
			}
			errormsg = checkValidYear(elementtocheck.value);
			if (errormsg.length > 1)
			{
				alert("Invalid YOB (Row " + count + ")" );
				elementtocheck.focus();
				exit;
			}
		}
	}
	//validate service dates
	for (count = 1; count < document.getElementById('services').rows.length; count++)
	{
		var elementtocheck = document.getElementById('date_'+ count)
		if (elementtocheck && elementtocheck.value.length > 0)
		{
			errormsg = checkValidDate(elementtocheck.value);
			if (errormsg.length > 1)
			{
				alert("Invalid Service Date (Row " + count + ")" );
				elementtocheck.focus();
				exit;
			}
		}
	}
	if (form.social_permanency_value && form.social_permanency_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_permanency_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_permanency_value.focus();
			exit;

		}
	}
	if (form.social_succession_value && form.social_succession_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_succession_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_succession_value.focus();
			exit;

		}
	}
	if (form.social_legal_value && form.social_legal_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_legal_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_legal_value.focus();
			exit;

		}
	}
	if (form.social_nursing_value && form.social_nursing_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_nursing_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_nursing_value.focus();
			exit;

		}
	}
	if (form.social_transport_value && form.social_transport_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_transport_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_transport_value.focus();
			exit;

		}
	}
	if (form.social_education_value && form.social_education_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_education_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_education_value.focus();
			exit;

		}
	}
	if (form.social_food_value && form.social_food_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_food_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_food_value.focus();
			exit;

		}
	}
	if (form.social_rent_value && form.social_rent_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_rent_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_rent_value.focus();
			exit;

		}
	}
	if (form.social_solidarity_value && form.social_solidarity_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_solidarity_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_solidarity_value.focus();
			exit;

		}
	}
	if (form.social_directsupport_value && form.social_directsupport_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_directsupport_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_directsupport_value.focus();
			exit;

		}
	}
	if (form.social_medicalsupport_value && form.social_medicalsupport_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_medicalsupport_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_medicalsupport_value.focus();
			exit;

		}
	}
	if (form.social_othersupport_value && form.social_othersupport_value.value.length > 0)
	{
		if (isNaN(parseInt(form.social_othersupport_value.value,10)) )
		{
			alert(" Invalid Value");
			form.social_othersupport_value.focus();
			exit;

		}
	}
	if(form.social_risk_level.value < 0){
		alert("Please select Risk level");
		form.social_risk_level.focus();
		exit;
	}

	form.submit();
}
// Given a tr node and row number (newid), this iterates over the row in the
// DOM tree, changing the id attribute to refer to the new row number.
function rowrenumber(newrow, newid, key)
{
  /*var curnode = newrow.firstChild;      // td node
  while (curnode) {
    var curitem = curnode.firstChild;   // input node (or whatever)
    while (curitem) {
      if (curitem.id) {  // replace row number in id
        var idx = 0;
        var spl = curitem.id.split('_');
        var baseid = spl[0];
        curitem.id = baseid + '_' + newid;
        if (curitem.name)
          curitem.name = baseid + '_' + newid;
        if (baseid == 'catno')
          curitem.tabIndex = newid;
      }
      curitem = curitem.nextSibling;
    }
    curnode = curnode.nextSibling;
  }*/
	var oldid;
	$j(newrow)
	.find('input[name^="'+key+'"]').attr('name',function(i,x){
		oldid=x.replace(key+'_','');
		return x;
	}).end()
	.html(function(i,x){
			var xr = new RegExp('_'+oldid,"g");
			return x.replace(xr,'_'+newid);
	});

}
// Appends a row to the given table, at the bottom of the table.

function AppendRow(table_id)
{
  var row = document.getElementById(table_id).rows.item(1);  // 1st row
  var newid = row.parentNode.rows.length;  // Since this includes the header row, we don't need to add one
  var newrow = row.cloneNode(true);

  rowrenumber(newrow, newid,'household_id');


    // Clear out data from new row.

  /*var curnode = document.getElementById('name_' + newid);
  curnode.value = "";
  curnode.tabIndex = newid;
  curnode = document.getElementById('yob_' + newid);
  curnode.value = "";
  curnode.nextSibling.onClick=popXCalendar("yob_"+newid);
  curnode = document.getElementById('gender_' + newid);
  curnode.value = "";
  curnode = document.getElementById('relationship_' + newid);
  curnode.value = "";
  curnode = document.getElementById('notes_' + newid);
  curnode.value = "";
  curnode = document.getElementById('delete_' + newid);
  curnode.innerHTML = "X";
  curnode = document.getElementById('delete_1');  // Really only need this when newid = 2
  curnode.innerHTML = "X";*/

  $j(newrow)
  	.find("input").val("").end()
  	.find("#delete_"+newid + " #delete_1").html("X");

  row.parentNode.appendChild(newrow);      // Attach to table
}

function AppendServiceRow(table_id)
{
  var row = document.getElementById(table_id).rows.item(1);  // 1st row
  var newid = row.parentNode.rows.length;  // Since this includes the header row, we don't need to add one
  var newrow = row.cloneNode(true);

  rowrenumber(newrow, newid,'social_services_id');
  $j(newrow)
  	.find("input").val("").end()
  	.find("#delete_"+newid + " #delete1").html("X");
  row.parentNode.appendChild(newrow);      // Attach to table

    // Clear out data from new row.

/*  var curnode = document.getElementById('service_' + newid);
  curnode.value = 0;
  curnode.tabIndex = newid;
  curnode = document.getElementById('date_' + newid);
  curnode.value = "";
  curnode = document.getElementById('notes_' + newid);
  curnode.value = "";
  curnode = document.getElementById('delete_' + newid);
  curnode.innerHTML = "X";
  curnode = document.getElementById('delete_1');  // Really only need this when newid = 2
  curnode.innerHTML = "X";*/

}
// Give a node within a row of the table (one level down from the td node),
// this deletes that row, renumbers the other rows accordingly, updates
// the Grand Total, and hides the delete button if there is only one row
// left.
function DeleteRow(el)
{
  var row = el.parentNode.parentNode;   // tr node
  var rownum = row.rowIndex;            // row to delete
  var tbody = row.parentNode;           // tbody node
  var numrows = tbody.rows.length - 1;  // don't count header row!
  if (numrows == 1)                     // can't delete when only one row left
    return false;

  var node = row;
  tbody.removeChild(node);
  var newid = -1;

    // Loop through tr nodes and renumber - only rows numbered
    // higher than the row we just deleted need renumbering.

  row = tbody.firstChild;
  while (row) {
    if (row.tagName == 'TR') {
      newid++;
      if (newid >= rownum){
    	  var key=$j("td:eq(0)  input",row).attr("name").replace(/_\d*$/,'');
          rowrenumber(row, newid,key);
      }
    }
    row = row.nextSibling;
  }
  if (numrows == 2) {  // 2 rows before deleting - only 1 left now, so 'hide' delete button
    var delbutton = document.getElementById('delete_1');
    //delbutton.innerHTML = ' ';
  }
}

function YNflipper(){
	var x=$j("input[name='social_change']:checked").val();
	if(x == 1){
		$j(".acare").show();
	}else{
		$j(".acare").hide();
	}


}

</script>

<form name="changeSocial" action="?m=social" method="post">
	<input type="hidden" name="dosql" value="do_social_aed" />
	<input type="hidden" name="social_id" value="<?php echo $social_id;?>" />
	<input type="hidden" name="social_client_id" value="<?php echo $client_id;?>" />
	<input type="hidden" id="household_num_rows" name="household_num_rows" value="" />
	<input type="hidden" id="service_num_rows" name="service_num_rows" value="" />
<table cellspacing="1" cellpadding="1" border="0" width='100%' class="std">


<tr>
<td valign="top" width="100%">


<table>
	<tr>
			<td colspan="2" align="left">
				<strong><?php echo $AppUI->_('Details'); ?><br /></strong>
				<hr width="500" align="left" size="1" />
			</td>
	</tr>
       <tr>
         <td align="left"><?php echo $AppUI->_('Officer');?>:</td>
		 <td align="left">
				<?php echo arraySelect( $owners, 'social_staff_id', 'size="1" class="text"', @$obj->social_staff_id ? $obj->social_staff_id:-1); ?>
		</td>

       </tr>
	   <tr>
         <td align="left"><?php echo $AppUI->_('Center');?>:</td>
         <td align="left">
		 <?php echo arraySelect($clinics, "social_clinic_id", 'class="text"', $obj->social_clinic_id ? $obj->social_clinic_id : -1 ); ?>
         </td>
		 </tr>
		 <tr>
		 <td align="left"><?php echo $AppUI->_('Date');?>: </td>
			<td align="left">
				<?php echo  drawDateCalendar('social_entry_date',($entry_date ? $entry_date->format( $df ) : ""),false,20);?>
			</td>
       </tr>
      <tr>

	 <tr>
         <td align="left"><?php echo $AppUI->_('Client Name');?>:</td>
         <td align="left">
		    <input type="text" class="text" name="social_client_name" value="<?php echo dPformSafe(@$clientObj->getFullName());?>" maxlength="150" size="20" disabled  readonly="readonly" />
         </td>
       </tr>
         <td align="left"><?php echo $AppUI->_('Adm No');?>:</td>
         <td align="left">
          <input type="text" class="text" name="social_client_code" value="<?php echo dPformSafe(@$clientObj->client_adm_no);?>" maxlength="150" size="20" disabled  readonly="readonly" />
         </td>
       </tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Type of Visit');?>:</td>

		<td>
		<?php echo arraySelectRadio($visitTypes, "social_visit_type", 'onclick=toggleButtons()', $obj->social_visit_type ? $obj->social_visit_type : -1, $identifiers ); ?>
		</td>
       </tr>
	 	<tr>
			<td colspan="2" align="left">
				<strong><?php echo $AppUI->_('Life Events'); ?><br /></strong>
				<hr width="500" align="left" size=1 />
			</td>
	 </tr>
	 <!--
       <tr>
         <td align="left"><?php //echo $AppUI->_('Client Status');?>:</td>
		 <td align="left">
				<?php //echo arraySelect( $socialstatusTypes, 'social_client_status', 'size="1" class="text"', @$obj->social_client_status ? $obj->social_client_status:-1); ?>
			</td>
       </tr>
	 -->
    <tr>
			<td align="left"><?php echo $AppUI->_('Client Status');?>: </td>
			<td>
				<?php echo arraySelect( $statusTypes, 'social_client_status', 'size="1" class="text"', @$obj->social_client_status ? $obj->social_client_status:$clientObj->client_status); ?>
			</td>
		</tr>
	<tr>
	<tr>
		<td align="left"><?php echo $AppUI->_('Client Health');?>: </td>
			<td>
				<?php echo arraySelectRadio( $clientHealth, 'social_client_health', 'size="1" class="text"', @$obj->social_client_health ? $obj->social_client_health:''); ?>
			</td>
		</tr>
	<tr>

         <td align="left"><?php echo $AppUI->_('Any Changes');?>:</td>
		 <td align="left"><?php echo arraySelectRadio($boolTypes, "social_change", 'onclick=YNflipper();', '2' , $identifiers );?>&nbsp;
		 </td>
	 </tr>

	 <tr class="acare">
         <td align="left"><?php echo $AppUI->_('Death');?>:</td>
		 <td align="left"><?php echo arraySelectRadio($deathTypes, "social_death", 'onclick=toggleButtons()', $obj->social_death , $identifiers );?>&nbsp;
		 </td>
	 </tr>
	 <tr class="acare">
         <td align="left">...<?php echo $AppUI->_('Other');?>:</td>
		 <td align="left"><input type="text" class="text" name="social_death_notes" value="<?php echo dPformSafe(@$obj->social_death_notes);?>" maxlength="40" size="40" />
		 </td>
	 </tr>

	 <tr class="acare">
         <td align="left">...<?php echo $AppUI->_('Date');?>:</td>
		 <td align="left">
		 	<?php echo drawDateCalendar('social_death_date',($death_date ? $death_date->format( $df ) : "" ),false);	 ?>
		 </td>
       </tr>
	  <tr class="acare">
        <td align="left" valign="top"><?php echo $AppUI->_("Change in caregiver");?>:</td>
        <td><?php echo arraySelectRadio($caretypes,'caregiver_type','',null);?>
        </td>
	  </tr>

		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Reason");?>:
		</td>
		<td>
		<?php echo arraySelectRadio($caregiverChangeTypes, "social_caregiver_change", 'onclick=toggleButtons()', $obj->social_caregiver_change ? $obj->social_caregiver_change : -1, $identifiers ); ?>
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Other");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_change_notes" value="<?php echo dPformSafe(@$obj->social_caregiver_change_notes);?>" maxlength="40" size="40" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("First Name");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_fname" value="<?php echo dPformSafe( @$admissionObj->admission_caregiver_fname);?>" maxlength="30" size="20" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Last Name");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_lname" value="<?php echo dPformSafe(@$admissionObj->admission_caregiver_lname);?>" maxlength="30" size="20" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Age");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_age" value="<?php echo dPformSafe(@$admissionObj->admission_caregiver_age);?>" maxlength="30" size="20" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Status");?>:
		</td>
		<td>
            <?php echo arraySelectRadio($caregiverHealthStatus, "social_caregiver_status", 'onclick=toggleButtons()', $obj->social_caregiver_status ? $obj->social_caregiver_status : -1, $identifiers ); ?>
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Relationship to Child");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_relationship" value="<?php echo dPformSafe(@$obj->social_caregiver_relationship);?>" maxlength="30" size="20" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Education level");?>:
		</td>
		<td>
            <?php echo arraySelectRadio($educationLevels, "social_caregiver_education", 'onclick=toggleButtons()', $obj->social_caregiver_education ? $obj->social_caregiver_education : -1, $identifiers ); ?>
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Employment");?>:
		</td>
		<td>
		 <?php echo arraySelectRadio($employmentTypes, "social_caregiver_employment", 'onclick=toggleButtons()', $obj->social_caregiver_employment ? $obj->social_caregiver_employment : -1, $identifiers ); ?>

		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("ID #");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_idno" value="<?php echo dPformSafe(@$obj->social_caregiver_idno);?>" maxlength="30" size="20" />
		</td>
		</tr>
		<tr class="acare">
		<td>
		...<?php echo $AppUI->_("Mobile #");?>:
		</td>
		<td>
            <input type="text" class="text" name="social_caregiver_mobile" value="<?php echo dPformSafe(@$obj->social_caregiver_mobile);?>" maxlength="30" size="20" />
		</td>
		</tr>
	  <tr class="acare">
        <td align="left" valign="top"><?php echo $AppUI->_("Change in health of primary caregiver");?>:</td>
	   </tr>
		<tr class="acare">
			<td>
			...<?php echo $AppUI->_("Health");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($caregiverHealthChanges, "social_caregiver_health", 'onclick=toggleButtons()', $obj->social_caregiver_health ? $obj->social_caregiver_health : -1, $identifiers ); ?></td>
		</tr>
		<tr class="acare">
			<td>
			...<?php echo $AppUI->_("Condition is hindrance on care for the child");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($boolTypesND, "social_caregiver_health_child_impact", 'onclick=toggleButtons()', $obj->social_caregiver_health_child_impact ? $obj->social_caregiver_health_child_impact : -1, $identifiers ); ?>
			</td>
		</tr>

	   <tr>
        <td align="left" valign="top" ><?php echo $AppUI->_("Change of Residence");?>:</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Mobile #");?>:
			</td>
			<td>
			<input type="text" class="text" name="social_caregiver_mobile" value="<?php echo dPformSafe(@$obj->social_caregiver_mobile);?>" maxlength="30" size="20" />
			</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Current residence (physical address and landmarks)");?>:
			</td>
			<td>
				<textarea cols="70" rows="2" class="textarea" name="social_residence"><?php echo dPformSafe(@$obj->social_residence);?></textarea>
			</td>
		</tr>
   <tr>
         <td align="left" nowrap="nowrap" valign="top"><?php echo $AppUI->_('Change in household composition');?>:</td>
		 <td align="left" class="std">
		 <table>
		   <tr>
		    <td>
				 <table id="family">
					 <th><?php echo $AppUI->_('Name');?></th>
					 <th><?php echo $AppUI->_('Year of Birth');?></th>
					 <th><?php echo $AppUI->_('Gender');?></th>
					 <th><?php echo $AppUI->_('Relationship to child');?></th>
					 <th><?php echo $AppUI->_('Comments');?></th>
					 <th>&nbsp;</th>

					 <?php
					 $rowcount = 1;
					 if (count($rows) > 0 )
					 {
						foreach ($rows as $row)
						{

					 ?>
					 <tr>
						 <td align="left">
						 <input type="hidden" name="household_id_<?php echo $rowcount; ?>" value="<?php echo @$row["household_id"]?>" />
						 <input type="text" class="text" id="name_<?php echo $rowcount; ?>" name="name_<?php echo $rowcount; ?>" value="<?php echo @$row["household_name"]?>" maxlength="150" size="20" />
						 </td>
						 <td align="left">
						 	<?php
						 	echo drawDateCalendar('yob_'.$rowcount,@$row['household_yob'],false,'id="yob_'.$rowcount.'"');
						 	//<input type="text" class="text" id="yob_<?php echo $rowcount; ?>" name="yob_<?php echo $rowcount; ?>" value="<?php echo @$row["household_yob"];?>" maxlength="150" size="20" />
						 	?>

						 </td>
						 <td align="left">
						 <?php echo arraySelect( $genderTypes, "gender_$rowcount", 'size="1" class="text" id="gender_'.$rowcount.'"', @$row["household_gender"] ); ?>

						 </td>
						 <td align="left"><input type="text" class="text" id="relationship_<?php echo $rowcount; ?>" name="relationship_<?php echo $rowcount; ?>" value="<?php echo @$row["household_relationship"];?>" maxlength="150" size="20" /></td>
						 <td align="left"><input type="text" class="text" id="notes_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$row["household_notes"];?>" maxlength="150" size="20" /></td>
						 <td align="left">
				              <span id="delete_<?php echo $rowcount; ?>" style="color:red; cursor: pointer;" onclick="DeleteRow(this);">X</span>
				         </td>
					 </tr>
					 <?php
							$rowcount++;
						} //end for
					  }
					  else
					  {
					  ?>
					  			 <tr>
						 <td align="left">
						 <input type="hidden" name="household_id_<?php echo $rowcount; ?>" value="<?php echo @$row["household_id"]?>" />
						 <input type="text" class="text" id="name_<?php echo $rowcount; ?>" name="name_<?php echo $rowcount; ?>" value="<?php echo @$row["household_name"]?>" maxlength="150" size="20" />
						 </td>
						 <td align="left">
						 	<?php
						 	echo drawDateCalendar('yob_'.$rowcount,@$row['household_yob'],false,'id="yob_'.$rowcount.'"');
						 	//<input type="text" class="text" id="yob_<?php echo $rowcount; " name="yob_<?php echo $rowcount; " value="<?php echo @$row["household_yob"];" maxlength="150" size="20" />
						 	?>

						 </td>
						 <td align="left">
						 	<?php echo arraySelect( $genderTypes, "gender_$rowcount", 'size="1" class="text" id="gender_'.$rowcount.'"', @$row["household_gender"] ); ?>
						 </td>
						 <td align="left"><input type="text" class="text" id="relationship_<?php echo $rowcount; ?>" name="relationship_<?php echo $rowcount; ?>" value="<?php echo @$row["household_relationship"];?>" maxlength="150" size="20" /></td>
						 <td align="left"><input type="text" class="text" id="notes_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$row["household_notes"];?>" maxlength="150" size="20" /></td>
						 <td align="left">
				              <span id="delete_<?php echo $rowcount; ?>" style="color:red; cursor: pointer;" onclick="DeleteRow(this);">X</span>
				         </td>
					 </tr>
					  <?php
					  }//end if
					 ?>
				</table>
			  </td>
            </tr>
		 <tr>
			<td>
				<input class="button" type="button" name="append" value="new entry" onclick="AppendRow('family'); return false;"/>
			</td>
		</tr>
		 </table>
		 <?php
            /*if ($AppUI->isActiveModule('relatives') && $perms->checkModule('relatives', 'view'))
		{
			echo "<input type='button' class='button' value='".$AppUI->_("enter household info...")."' onclick='javascript:popRelatives();' />";
		}*/
		?>
		 </td>
	  </tr>
	   <tr>
        <td align="left" valign="top"><?php echo $AppUI->_("Change in household income level");?>:</td>
        </tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Change due to employment type of primary caregiver");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($boolTypes, "social_caregiver_employment_change", 'onclick=toggleButtons()', $obj->social_caregiver_employment_change ? $obj->social_caregiver_employment_change : -1, $identifiers ); ?>
			</td>

		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("If yes, new employment");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($employmentTypes, "social_caregiver_new_employment", 'onclick=toggleButtons()', $obj->social_caregiver_new_employment ? $obj->social_caregiver_new_employment : -1, $identifiers ); ?>
			</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Other");?>:
			</td>
			<td>
			<input type="text" class="text" name="social_caregiver_new_employment_desc" value="<?php echo dPformSafe(@$obj->social_caregiver_new_employment_desc);?>" maxlength="40" size="40" />
			</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("New income range");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($incomeLevels, "social_caregiver_new_income", 'onclick=toggleButtons()', $obj->social_caregiver_new_income ? $obj->social_caregiver_new_income : -1, $identifiers ); ?>
			</td>
		</tr>
	   <tr>
        <td align="left" valign="top"><?php echo $AppUI->_("Change in schooling");?>:</td>
        </tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Attendance");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($childSchoolStatus, "social_school_attendance", 'onclick=toggleButtons()', $obj->social_school_attendance ? $obj->social_school_attendance : -1, $identifiers ); ?>

			</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("New school level");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($childSchoolLevels, "social_school", 'onclick=toggleButtons()', $obj->social_school ? $obj->social_school : -1, $identifiers ); ?></td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("If not attending, why");?>:
			</td>
			<td>
			<?php echo arraySelectRadio($reasonsNotAttendingSchool, "social_reason_not_attending", 'onclick=toggleButtons()', $obj->social_reason_not_attending ? $obj->social_reason_not_attending : -1, $identifiers ); ?></td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Other");?>:
			</td>
			<td>
				<input type="text" class="text" name="social_reason_not_attending_notes" value="<?php echo dPformSafe(@$obj->social_reason_not_attending_notes);?>" maxlength="40" size="40" />
			</td>
		</tr>
		<tr>
			<td>
			...<?php echo $AppUI->_("Current class / form");?>:
			</td>
			<td>
				<input type="text" class="text" name="social_class_form" value="<?php echo dPformSafe(@$obj->social_class_form);?>" maxlength="40" size="40" />
			</td>

		</tr>

	<tr>
			<td colspan="2" align="left">
				<strong><?php echo $AppUI->_('Needs supported'); ?><br /></strong>
				<hr width="500" align="left" size=1 />
			</td>
	 </tr>

   <tr>
         <td align="left" nowrap="nowrap" valign="top"><?php echo $AppUI->_('Services Rendered');?>:</td>
		 <td align="left" class="std">
		 <table>
		   <tr>
		    <td>
				 <table id="services">
					 <th><?php echo $AppUI->_('Service');?></th>
					 <th><?php echo $AppUI->_('Date (dd/mm/yyyy)');?></th>
					 <th><?php echo $AppUI->_('Comments');?></th>
					 <th><?php echo $AppUI->_('Value');?></th>
					 <th>&nbsp;</th>

					 <?php
					 $rowcount = 1;
					 if (count($servicerows) > 0 )
					 {
						foreach ($servicerows as $servicerow)
						{
						//var_dump($servicerow);
					 ?>
					 <tr>
						 <td align="left">
						 <input type="hidden" name="social_services_id_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_id"]?>" />
						 <?php echo arraySelect( $serviceTypes, "service_$rowcount", 'size="1" class="text" id="service_'.$rowcount.'"', @$servicerow["social_services_service_id"] ); ?>
						 </td>
						 <td align="left">
						 <?php
						 	$service_date = new CDate( @$servicerow["social_services_date"] );
						 	echo drawDateCalendar('date_'.$rowcount,@$service_date->format( $df ),false,'id="date_'.$rowcount.'"');
						 	//<input type="text" class="text" id="date_<?php echo $rowcount; " name="date_<?php echo $rowcount; " value="<?php $service_date = new CDate( @$servicerow["social_services_date"] );  echo  @$service_date->format( $df );" maxlength="150" size="20" />
						 ?>

						 	</td>
						 <td align="left"><input type="text" class="text" id="notes_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_notes"];?>" maxlength="150" size="20" /></td>
						 <td align="left"><input type="text" class="text" id="notes_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_value"];?>" maxlength="150" size="5" /></td>
						 <td align="left">
				              <span id="delete_<?php echo $rowcount; ?>" style="color:red; cursor: pointer;" onclick="DeleteRow(this);">X</span>
				         </td>
					 </tr>
					 <?php
							$rowcount++;
						} //end for
					  }
					  else
					  {

					  ?>
					  <tr>
						 <td align="left">
						 <input type="hidden" name="social_services_id_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_id"]?>" />
						 <?php echo arraySelect( $serviceTypes, "service_$rowcount", 'size="1" class="text" id="service_'.$rowcount.'"', @$servicerow["social_services_service_id"] ); ?>
						 </td>
						 <td align="left">
						 <?php
						 	intval (@$servicerow["social_services_date"]) > 0 ? $service_date = new CDate( @$servicerow["social_services_date"] ) : NULL;  $vval= ($service_date) ? $service_date->format( $df ) : "";
						 	echo drawDateCalendar('date_'.$rowcount,$vval,false,'id="date_'.$rowcount.'"');
						 	//<input type="text" class="text" id="date_<?php echo $rowcount; " name="date_<?php echo $rowcount; " value="<?php intval (@$servicerow["social_services_date"]) > 0 ? $service_date = new CDate( @$servicerow["social_services_date"] ) : NULL;  echo  ($service_date) ? $service_date->format( $df ) : "";" maxlength="150" size="20" /></td>
						 ?>
						 <td align="left"><input type="text" class="text" id="notes_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_notes"];?>" maxlength="150" size="20" /></td>
						 <td align="left"><input type="text" class="text" id="value_<?php echo $rowcount; ?>" name="notes_<?php echo $rowcount; ?>" value="<?php echo @$servicerow["social_services_value"];?>" maxlength="150" size="5" /></td>
						 <td align="left">
				              <span id="delete_<?php echo $rowcount; ?>" style="color:red; cursor: pointer;" onclick="DeleteRow(this);">X</span>
				         </td>
					 </tr>
					  <?php
					  }//end if
					 ?>
				</table>
			  </td>
            </tr>
		 <tr>
			<td>
				<input class="button" type="button" name="append" value="new entry" onclick="AppendServiceRow('services'); return false;"/>
			</td>
		</tr>
		 </table>
		 <?php
            /*if ($AppUI->isActiveModule('relatives') && $perms->checkModule('relatives', 'view'))
		{
			echo "<input type='button' class='button' value='".$AppUI->_("enter household info...")."' onclick='javascript:popRelatives();' />";
		}*/
		?>
		 </td>
	  </tr>

	 	<tr>
			<td colspan="2" align="left">
				<strong><?php echo $AppUI->_('Needs assessment'); ?><br /></strong>
				<hr width="500" align="left" size=1 />
			</td>
	 </tr>
      <tr>
			<td align="left" valign="top"><?php echo $AppUI->_('Permanency Planning');?>:</td>
	  </tr>
	 <tr>
			<td>
			...<?php echo $AppUI->_("Relocation");?>:
			</td>
			<td>
			<?php echo arraySelectCheckbox($relocationTypes, "social_relocation[]", NULL, $relocation_options ); ?>
			</td>
	</tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("IGA");?>:
			</td>
			<td>
	        	<?php echo arraySelectCheckbox($igaTypes, "social_iga[]", NULL, $iga_options ); ?>

			</td>

	</tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Placement");?>:
			</td>
			<td>
	          <?php echo arraySelectCheckbox($placementTypes, "social_placement[]", NULL, $placement_options ); ?>
			</td>

	</tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_permanency_value" value="<?php echo dPformSafe(@$obj->social_permanency_value);?>" maxlength="30" size="20" />

			</td>

	</tr>
	<tr>
			<td align="left"><?php echo $AppUI->_('Succession Planning');?>:</td>
			<td align="left" valign="top">
	          <?php echo arraySelectCheckbox($successionPlanningTypes, "social_succession_planning[]", NULL, $succession_planning_options ); ?>
			</td>
      </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_succession_value" value="<?php echo dPformSafe(@$obj->social_succession_value);?>" maxlength="30" size="20" />

			</td>

	</tr>
	  <tr>
			<td align="left"><?php echo $AppUI->_('Legal');?>:</td>
			<td align="left" valign="top">
				          <?php echo arraySelectCheckbox($legalIssues, "social_legal[]", NULL, $legal_options ); ?>
			</td>
      </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_legal_value" value="<?php echo dPformSafe(@$obj->social_legal_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
	  <tr>
			<td align="left"><?php echo $AppUI->_('Nursing/Palliative Care');?>:</td>
			<td align="left" valign="top">
			<?php echo arraySelectCheckbox($nursingCareTypes, "social_nursing[]", NULL, $nursing_options ); ?>
			</td>
      </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_nursing_value" value="<?php echo dPformSafe(@$obj->social_nursing_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
	  <tr>
			<td align="left"><?php echo $AppUI->_('Transport');?>:</td>
			<td align="left" valign="top">
				<?php echo arraySelectCheckbox($transportNeeds, "social_transport[]", NULL, $transport_options ); ?>
			</td>
      </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_transport_value" value="<?php echo dPformSafe(@$obj->social_transport_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Education');?>:</td>
		<td>
		<?php echo arraySelectCheckbox($educationNeeds, "social_education[]", NULL, $education_options ); ?>
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_education_value" value="<?php echo dPformSafe(@$obj->social_education_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Food');?>:</td>
		<td>
		<?php echo arraySelectCheckbox($foodNeeds, "social_food[]", NULL, $food_options ); ?>
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_food_value" value="<?php echo dPformSafe(@$obj->social_food_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Rent');?>:</td>
		<td>
			<?php echo arraySelectCheckbox($rentNeeds, "social_rent[]", NULL, $rent_options ); ?>
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_rent_value" value="<?php echo dPformSafe(@$obj->social_rent_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Solidarity');?>:</td>
		<td>
			<?php echo arraySelectCheckbox($solidarityNeeds, "social_solidarity[]", NULL, $solidarity_options ); ?>
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_solidarity_value" value="<?php echo dPformSafe(@$obj->social_solidarity_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Direct Support');?>:</td>
		<td>
		  <?php echo arraySelectCheckbox($directSupportNeeds, "social_direct_support[]", NULL, $direct_support_options ); ?>
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_directsupport_value" value="<?php echo dPformSafe(@$obj->social_directsupport_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('Medical Support');?>:</td>
		<td>
		   <?php echo arraySelectCheckbox($medicalSupportNeeds, "social_medical_support[]", NULL, $medical_support_options ); ?>
		</td>
       </tr>
       <tr>
        <td align="left">...<?php echo $AppUI->_('Other');?>:</td>
		<td>
		<input type="text" class="text" name="social_medical_support_desc" value="<?php echo dPformSafe(@$obj->social_medical_support_desc);?>" maxlength="40" size="40" />
		</td>
       </tr>
       <tr>
         <td align="left"><?php echo $AppUI->_('Training Support');?>:</td>
		<td>
		   <?php echo arraySelectRadio($trainingSupport, "social_training",'onclick=toggleButtons()', $obj->social_training ? $obj->social_training : -1, $indentifiers ); ?>
		</td>
       </tr>
       <tr>
        <td align="left">...<?php echo $AppUI->_('Other');?>:</td>
		<td>
		<input type="text" class="text" name="social_training_desc" value="<?php echo dPformSafe(@$obj->social_training_desc);?>" maxlength="40" size="40" />
		</td>
       </tr>
	  <tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_medicalsupport_value" value="<?php echo dPformSafe(@$obj->social_medicalsupport_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
	   <tr>
        <td align="left"><?php echo $AppUI->_('Other Needs Assessed');?>:</td>
		<td>
		<input type="text" class="text" name="social_other_support" value="<?php echo dPformSafe(@$obj->social_other_support);?>" maxlength="40" size="40" />
		</td>
       </tr>
	<tr>
			<td>
			...<?php echo $AppUI->_("Value");?>:
			</td>
			<td>
	           <input type="text" class="text" name="social_othersupport_value" value="<?php echo dPformSafe(@$obj->social_othersupport_value);?>" maxlength="30" size="20" />

			</td>
	</tr>
		<tr>
         <td align="left"><?php echo $AppUI->_('New Risk Level');?>:</td>
		<td>
		<?php echo arraySelect($riskLevels, "social_risk_level", 'class="text"', $obj->social_risk_level  ? $obj->social_risk_level : -1, $identifiers ); ?>
		</td>
       </tr>
       <tr>
         <td align="left"><?php echo $AppUI->_('Next Appointment Date');?>:</td>
		<td>
		<?php echo drawDateCalendar('social_next_visit',$obj->social_next_visit ? $obj->social_next_visit : '',false); ?>
		</td>
       </tr>
       <tr>
         <td align="left"><?php echo $AppUI->_('Referral to');?>:</td>
		<td>
		<?php echo arraySelect($positionOptions, "social_referral", 'class="text"', $obj->social_referral  ? $obj->social_referral : '', $identifiers );?>
		</td>
       </tr>
	   <tr>
	   <td align='left'>
		<?php
 			require_once("./classes/CustomFields.class.php");
 			$custom_fields = New CustomFields( $m, $a, $obj->social_id, "edit" );
 			$custom_fields->printHTML();
		?>
	</td>
       </tr>
		<tr>
		 <td align="left" valign="top"><?php echo $AppUI->_('Comments');?>:</td>
<td valign="top">
		<textarea cols="70" rows="2" class="textarea" name="social_notes"><?php echo @$obj->social_notes;?></textarea>
		</td>
		</tr>

	   </table>
</td>


</td>
</tr>


<tr>
	<td><input type="button" value="<?php echo $AppUI->_('back');?>" class="button" onClick="javascript:history.back(-1);" /></td>
	<td align="right"><input type="button" value="<?php echo $AppUI->_('submit');?>" class="button" onClick="submitIt()" /></td>
</tr>

</table>
</form>
