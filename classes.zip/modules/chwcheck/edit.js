function initEdits(){
	
}
