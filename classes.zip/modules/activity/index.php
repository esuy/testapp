<?php
$AppUI->redirect( "m=training" );

?>