<?php 

class smartsearch extends CDpObject  {

	var $table = NULL;
	var $follow_up_link = NULL;
	var $keyword = NULL;
	
	var $search_fields = NULL;
	
	function smartsearch(){
		return null;
	}
}	

?>
