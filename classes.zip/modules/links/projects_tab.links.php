<?php /* PROJECTS $Id: projects_tab.links.php,v 1.1.1.1.2.2 2005/09/13 14:11:33 pedroix Exp $ */
GLOBAL $AppUI, $project_id, $deny, $canRead, $canEdit, $dPconfig;

$showProject = false;
require( dPgetConfig('root_dir') . '/modules/links/index_table.php' );
?>
