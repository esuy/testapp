<?php

if($_GET['mode'] == 'add_file'){
	
}else{
	require_once('imported.inc.php');
}

?>