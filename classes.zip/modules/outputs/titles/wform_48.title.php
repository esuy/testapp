<?php
$titles["wform_48"]=
		array(
			"title" => "test par-ch",
			"db"=>"wform_48",
			"client"=>false,
			"uid"=>"tbw48",
			"date"=>"entry_date",
			"client_name"=> "concat(client_first_name,' ',client_last_name) as client_name",
			"did"=>"id",
			"defered"=>array(),
			"abbr"=>"WF48",
			"link"=>array("href"=>"?m=wizard&a=form_use&client_id=#client_id#&itemid=#did#&fid=48&todo=addedit","vals"=>array("client_id","did")),
			"plurals"=>array(),
			"referral"=>"",
			"next_visit"=>"",
			"form_type"=>"contus"
		);
?>