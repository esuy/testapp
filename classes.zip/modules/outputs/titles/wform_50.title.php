<?php
$titles["wform_50"]=
		array(
			"title" => "fffff super iron man",
			"db"=>"wform_50",
			"client"=>"client_id",
			"uid"=>"tbw50",
			"date"=>"entry_date",
			"client_name"=> "concat(client_first_name,' ',client_last_name) as client_name",
			"did"=>"id",
			"defered"=>array(),
			"abbr"=>"WF50",
			"link"=>array("href"=>"?m=wizard&a=form_use&client_id=#client_id#&itemid=#did#&fid=50&todo=addedit","vals"=>array("client_id","did")),
			"plurals"=>array(),
			"referral"=>"",
			"next_visit"=>"",
			"form_type"=>"contus"
		);
?>