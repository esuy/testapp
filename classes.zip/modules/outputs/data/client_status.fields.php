<?php
$partShow=false;

$selects=array();

$fields = array(
'social_client_status' => array('title'=>'Client Status (LOG)','value'=>'sysval','query'=>'ClientStatus'),
'social_entry_date'=>array('title'=>'Date of Change','xtype'=>'date'),
);
?>