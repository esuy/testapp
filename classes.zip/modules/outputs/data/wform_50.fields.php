<?php
$partShow=true;
$selects = array();
$fields=array("fld_0" => array("title"=>"1.Region","value"=>"sysval","query"=>"Region"),
"fld_1" => array("title"=>"2.Municip","value"=>"sysval","query"=>"Municipality"),
"fld_2" => array("title"=>"3.Village","value"=>"sysval","query"=>"Village"));
?>