<?php
$partShow=true;
$selects = array();
$fields=array("fld_0" => array("title"=>"1.h4v rrn ergn","xtype"=>"date"),
"fld_1" => "2.numero",
"fld_2" => array("title"=>"3.tjhrtjhrthjrthj","value"=>"sysval","query"=>"7"),
"fld_3" => array("title"=>"4.yyyym bhhgh","value"=>"sysval","query"=>"46"));
?>