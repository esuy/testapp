<?php
$partShow=false;
$fields = array(
	"clinic_name" => "Clinic Name"
);

?>