<?php
$partShow=true;
$selects = array();
$fields=array("fld_0" => array("title"=>"1.fgfgf","value"=>"sysval","query"=>"21","mode"=>"multi"),
"fld_1" => array("title"=>"2.peaches","value"=>"sysval","query"=>"44"),
"fld_2" => array("title"=>"3.Dateee","xtype"=>"date"));
?>